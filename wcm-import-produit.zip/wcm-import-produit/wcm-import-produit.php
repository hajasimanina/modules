<?php
/*
 * Plugin Name: WooCommerce Import Produit
 * Description: Module WP qui permet d'importer des produits pour WooCommerce à partir d'un fichier EXCEL.
 * Version: 1.0
 * Author: Pascal & Fetra
 * Text Domain: wcm-pip
 * Domain Path: /i18n/languages/
 * Requires at least: 6.2
 * Requires PHP: 7.3 or latest
*/

define( 'WIP_ROOT_DIR' , plugin_dir_path( __FILE__ ) );
define( 'WIP_URL' , plugin_dir_url( __FILE__ ) );
define( 'WIP_PRIMARY_LANG' , 'wcm-pip' );
define( 'WIP_UPLOAD_DIR' , '/wip-woocommerce/' );
require_once( WIP_ROOT_DIR . 'inc/functions.php' );
require_once( WIP_ROOT_DIR . 'inc/admin-page.class.php' );
require_once( WIP_ROOT_DIR . 'inc/wp-progress-action.php' );
require_once( WIP_ROOT_DIR . '/lib/Spout/Autoloader/autoload.php' );

new WIP_Admin_Page();