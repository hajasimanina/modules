jQuery(document).ready(function ($) {
    let _uploader = $('.wcm-ip-uploader-inline');
    let _close = $('.wip-content-page button.close');
    let _add = $('.wcm-import-add-file');
    /*Manage click add file*/
    _add.on('click', function (e) {
        e.preventDefault();
        $(this).addClass('active');
        _uploader.removeClass('hidden')
    });

    /*Manage close button*/
    _close.on('click', function (e) {
        e.preventDefault();
        $(this).parent().css('display', 'none')
    });

    //Ajax progress
    $('.wip-run-product-import').on('click', function (e) {
        e.preventDefault();
        $('.wip-import-progress-content .spinner').addClass('is-active');
        $('.wip-import-progress-content p.message').empty().text('Vos produits sont maintenant en cours d\'importation...');
        let _nonce = $(this).data('action');
        let _step_name = $(this).data('step_name');
        $.ajax({
            type: 'POST',
            url: wip_object.ajaxurl,
            data: {
                action: 'wip_do_ajax_product_import',
                wip_nonce: _nonce,
                step_name: _step_name,
            },
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    $this.$form.find('.wip-importer-progress').val(response.data.percentage);
                }
            }
        }).fail(function (response) {
            window.console.log(response);
        });
    });

    $("#progress-bar-processus-stop").on('click', function () {
        $.ajax({
            type: 'POST',
            url: ajaxurl,
            data: {
                action: 'wip_do_ajax_import_delete',
                step: 'upload',
            },
            dataType: 'json',
            success: function (response) {
                console.log(response)
            }
        }).fail(function (response) {
            window.console.log(response);
        });
    })
});
