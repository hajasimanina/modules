<?php
/*Header*/
WIP_Admin_Page::dispatch( 'header' );

/*Steps*/
WIP_Admin_Page::dispatch( 'steps' );

/*Content*/
WIP_Admin_Page::dispatch( $current_step );

/*Footer*/
WIP_Admin_Page::dispatch( 'footer' );