<div class="wrap">
    <div class="wip-header">
        <h1>
            <?php echo __( 'Import des produits pour WooCommerce via un fichier EXCEL' , WIP_PRIMARY_LANG ); ?>
        </h1>
    </div>
<div class="wrap woocommerce">
    <div class="wip-progress-form-wrapper">