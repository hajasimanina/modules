<?php
/**
 * Admin View: Product import form
 *
 * @package WooCommerce\Admin
 */

if ( !defined( 'ABSPATH' ) ) {
	exit;
}
$bytes      = apply_filters( 'import_upload_size_limit' , wp_max_upload_size() );
$size       = size_format( $bytes );
$upload_dir = wp_upload_dir();
global $wip_error;
?>
<form class="wip-progress-form-content wip-importer" enctype="multipart/form-data" method="post">
	<?php wp_nonce_field( 'upload' , '_wpnonce_wip' ); ?>
    <header>
        <h2>
			<?php esc_html_e( 'Importer des produits à partir d’un fichier EXCEL' , WIP_PRIMARY_LANG ); ?>
        </h2>
        <p>
			<?php esc_html_e( 'Cet outil vous permet d’importer (ou de fusionner) des données de produit dans votre boutique à partir d’un fichier EXCEL.' , WIP_PRIMARY_LANG ); ?>
        </p>
    </header>
    <section>
        <table class="form-table wip-importer-options">
            <tbody>

            <!--Error-->
            <tr>
				<?php if ( !empty( $wip_error['upload'] ) ) : ?>
					<?php
					$error_nb = ( count( $wip_error['upload'] ) > 1 ) ? 's' : '';
					?>
                    <div class="inline error">
                        <p>
							<?php esc_html_e( "Erreur$error_nb à corriger avant de continuer" , WIP_PRIMARY_LANG ); ?>
                        </p>
						<?php foreach ( $wip_error['upload'] as $item ) : ?>
                            <p>
                                <strong>
									<?php echo esc_html( '- ' . $item ); ?>
                                </strong>
                            </p>
						<?php endforeach; ?>
                    </div>
				<?php endif; ?>
            </tr>

            <!--File-->
            <tr>
                <th scope="row">
                    <label for="upload">
						<?php esc_html_e( 'Choisir un fichier EXCEL à partir de votre ordinateur:' , WIP_PRIMARY_LANG ); ?>
                    </label>
                </th>
                <td>
                    <input type="file" id="upload" name="upload" accept=".xls,.xlsx"/>
                    <input type="hidden" name="max_file_size" value="<?php echo esc_attr( $bytes ); ?>"/>
                    <br>
                    <small>
						<?php
						printf(
							esc_html__( 'Taille maximum : %s' , WIP_PRIMARY_LANG ) ,
							esc_html( $size )
						);
						?>
                    </small>

                </td>
            </tr>

            <!--Options-->
            <tr>
                <th>
                    <label for="wip-importer-update-existing">
						<?php esc_html_e( 'Mettre à jour les produits existants' , WIP_PRIMARY_LANG ); ?>
                    </label>
                    <br/>
                </th>
                <td>
                    <input type="hidden" name="update_existing" value="0"/>
                    <input type="checkbox" id="wip-importer-update-existing" name="update_existing" value="1"/>
                    <label for="wip-importer-update-existing">
						<?php esc_html_e( 'Les produits existants correspondants à l’ID ou à l’UGS seront mis à jour. Les autres seront ignorés.' , WIP_PRIMARY_LANG ); ?>
                    </label>
                </td>
            </tr>

            <tr>
                <th>
                    <label>
						<?php esc_html_e( 'Encodage des caractères du fichier :' , WIP_PRIMARY_LANG ); ?>
                    </label>
                    <br/>
                </th>
                <td>
                    <select id="wip-importer-character-encoding" name="character_encoding">
                        <option value="" selected>
							<?php esc_html_e( 'Détection automatique' , WIP_PRIMARY_LANG ); ?>
                        </option>
						<?php
						$encodings = mb_list_encodings();
						sort( $encodings , SORT_NATURAL );
						?>
						<?php if ( !empty( $encodings ) ): ?>
							<?php foreach ( $encodings as $encoding ) : ?>
								<?php echo '<option>' . esc_html( $encoding ) . '</option>'; ?>
							<?php endforeach; ?>
						<?php endif; ?>
                    </select>
                </td>
            </tr>
            </tbody>
        </table>
    </section>

    <div class="wip-actions">
        <input type="hidden" name="wip-step-name" value="upload">
        <input type="hidden" name="action" value="wip-save-step"/>
        <button type="submit" class="button button-primary button-next"
                value="<?php esc_attr_e( 'Continuer' , WIP_PRIMARY_LANG ); ?>"
                name="save_step"><?php esc_html_e( 'Continuer' , WIP_PRIMARY_LANG ); ?>
        </button>
    </div>
</form>
