<?php
$headers         = WipImport::mapping_headers();
$mapping_options = WipImport::get_mapping_options();
$mapped_items    = WipImport::auto_map_columns( $headers );
$sample          = WipImport::mapping_data();
$uploaded_file   = wip_uploaded_excel();
?>
<form class="wip-progress-form-content wip-importer" method="post" action="">
    <header>
        <h2><?php esc_html_e( 'Mapper les champs EXCEL aux produits' , WIP_PRIMARY_LANG ); ?></h2>
        <p><?php esc_html_e( 'Sélectionner les champs de votre fichier EXCEL à associer aux champs de produits, ou à ignorer lors de l’importation.' , WIP_PRIMARY_LANG ); ?></p>
    </header>
    <section class="wc-importer-mapping-table-wrapper">
        <table class="widefat wip-importer-mapping-table">
            <thead>
            <tr>
                <th><?php esc_html_e( 'Nom des colonnes' , WIP_PRIMARY_LANG ); ?></th>
                <th><?php esc_html_e( 'Mapper les champs' , WIP_PRIMARY_LANG ); ?></th>
            </tr>
            </thead>
            <tbody>
			<?php foreach ( $headers as $index => $name ) : ?>
				<?php $mapped_value = $mapped_items[ $index ]; ?>
                <tr>
                    <td class="wip-importer-mapping-table-name">
						<?php echo esc_html( $name ); ?>
						<?php if ( !empty( $sample[ $index ] ) ) : ?>
                            <span class="description">
                                <?php esc_html_e( 'Ex:' , WIP_PRIMARY_LANG ); ?>
                                <code><?php echo
	                                esc_html( $sample[ $index ] ); ?>
                                </code>
                            </span>
						<?php endif; ?>
                    </td>
                    <td class="wip-importer-mapping-table-field">
                        <input type="hidden" name="map_from[<?php echo esc_attr( $index ); ?>]"
                               value="<?php echo esc_attr( $name ); ?>"/>
                        <select name="map_to[<?php echo esc_attr( $index ); ?>]">
                            <option value=""><?php esc_html_e( 'Ne pas importer' , WIP_PRIMARY_LANG ); ?></option>
                            <option value="">--------------</option>
							<?php foreach ( WipImport::get_mapping_options( $mapped_value ) as $key => $value ) : ?>
								<?php if ( is_array( $value ) ) : ?>
                                    <optgroup label="<?php echo esc_attr( $value['name'] ); ?>">
										<?php foreach ( $value['options'] as $sub_key => $sub_value ) : ?>
                                            <option value="<?php echo esc_attr( $sub_key ); ?>" <?php selected( $mapped_value , $sub_key ); ?>><?php echo esc_html( $sub_value ); ?></option>
										<?php endforeach ?>
                                    </optgroup>
								<?php else : ?>
                                    <option value="<?php echo esc_attr( $key ); ?>" <?php selected( $mapped_value , $key ); ?>><?php echo esc_html( $value ); ?></option>
								<?php endif; ?>
							<?php endforeach ?>
                        </select>
                    </td>
                </tr>
			<?php endforeach; ?>
            </tbody>
        </table>
    </section>
    <div class="wip-actions">
		<?php wp_nonce_field( 'mapping' , '_wpnonce_wip' ); ?>
        <input type="hidden" name="wip-step-name" value="mapping">
        <input type="hidden" name="uploaded_file" value="<?php echo $uploaded_file; ?>"/>
        <input type="hidden" name="action" value="wip-save-step"/>
        <button type="submit" class="button button-primary button-next"
                value="<?php esc_attr_e( 'Lancer l’importation' , WIP_PRIMARY_LANG ); ?>"
                name="save_step">
			<?php esc_html_e( 'Enregistrer' , WIP_PRIMARY_LANG ); ?>
        </button>
    </div>
</form>