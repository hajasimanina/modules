<?php
$steps = array(
	'upload'   => array(
		'name'    => __( 'Téléverser un fichier EXCEL' , WIP_PRIMARY_LANG ) ,
		'view'    => array( 'WIP_Import' , 'upload' ) ,
		'handler' => array( 'WIP_Import' , 'upload_form_handler' ) ,
		'icon'    => 'dashicons-plus-alt' ,
	) ,
	'mapping'  => array(
		'name'    => __( 'Mappage des colones' , WIP_PRIMARY_LANG ) ,
		'view'    => array( 'WIP_Import' , 'mapping' ) ,
		'handler' => '' ,
		'icon'    => 'dashicons-editor-spellcheck' ,
	) ,
	'progress' => array(
		'name'    => __( 'Importer' , WIP_PRIMARY_LANG ) ,
		'view'    => array( 'WIP_Import' , 'import' ) ,
		'handler' => '' ,
		'icon'    => 'dashicons-database-import' ,
	) ,
	'done'     => array(
		'name'    => __( 'Terminé' , WIP_PRIMARY_LANG ) ,
		'view'    => array( 'WIP_Import' , 'done' ) ,
		'handler' => '' ,
		'icon'    => 'dashicons-products' ,
	) ,
);
global $current_step;
if ( $current_step === 'upload' ) {
	$exist_upload                           = true;
	$is_active                              = ( $exist_upload ) ? 'active' : '';
	$steps[ $current_step ]['class_active'] = $is_active;
} else {
	switch ( $current_step ) {
		case 'mapping':
			$steps['upload']['class_active'] = 'active';
			break;
		case 'progress':
			$steps['upload']['class_active']  = 'active';
			$steps['mapping']['class_active'] = 'active';
			break;
		case 'done':
			$steps['upload']['class_active']   = 'active';
			$steps['mapping']['class_active']  = 'active';
			$steps['progress']['class_active'] = 'active';
			break;
	}
	$steps[ $current_step ]['class_active'] = 'active';
}

?>
<ol class="wip-progress-steps">
	<?php foreach ( $steps as $step_key => $item ) : ?>
		<?php
		$step_class = ( isset( $item['class_active'] ) ) ? $item['class_active'] : '';
		?>
        <li class="<?php echo esc_attr( $step_class ); ?>">
            <i class="dashicons <?php echo $item['icon']; ?>"></i>
			<?php echo esc_html( $item['name'] ); ?>
        </li>
	<?php endforeach; ?>
</ol>
