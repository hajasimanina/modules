<?php
/**
 * Admin View: Importer - CSV import progress
 *
 * @package WooCommerce\Admin\Importers
 */

if ( !defined( 'ABSPATH' ) ) {
    exit;
}
require_once( WIP_ROOT_DIR . 'inc/wp-progress-action.php' );
$wip_mapping_pref = get_user_option( 'woocommerce_product_import_mapping' );
$mapping          = get_user_option( 'wip_product_import_mapping_user' , get_current_user_id() );
$mapped           = array_combine( $mapping['mapping']['from'] , $mapping['mapping']['to'] );
$raw_keys         = WipImport::mapping_headers();

$raw_keys = array_map( array( 'WipImport' , 'adjust_character_encoding' ) , $raw_keys );
//WipImport::do_ajax_product_import();

$element = 'wip-import-produits';
//ajouter le hook pour specifier les ids à traiter
add_filter( 'progress_action_data_' . $element , 'wip_ajax_callback' );
function wip_ajax_callback( $data ) {
    $sheets_number = get_user_option( 'wip_product_import_number' , get_current_user_id() );
    $sheets_number = ( !empty( $sheets_number ) ) ? $sheets_number : array();

    return $sheets_number;
}

//ajouter le hook pour faire le traitement des elements
add_filter( 'progress_action_callback_' . $element , 'wip_ajax_action_callback' );
function wip_ajax_action_callback( $id ) {
    $item = WipImport::mapping_data($id);
    mp($item);
    return true;
}

//display form
$progress_action = new WP_Progress_Action( $element , 'Produit' , array( 'process_title' => 'Import des produits Woocommerce' ) );
//mp( $ajax );
$progress_action->display();