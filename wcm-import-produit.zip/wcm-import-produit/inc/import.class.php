<?php

use Automattic\WooCommerce\Utilities\I18nUtil;
use Box\Spout\Common\Exception\IOException;
use Box\Spout\Common\Exception\UnsupportedTypeException;
use Box\Spout\Common\Type;
use Box\Spout\Reader\Exception\ReaderNotOpenedException;
use Box\Spout\Reader\ReaderFactory;

require_once( WIP_ROOT_DIR . '/inc/validation.php' );

class WipImport
{
    /**
     * WipImport constructor.
     */
    public function __construct() {
    }

    /**
     * Process in each step
     */
    public static function save_step() {
        $wip_page = wip_get_page();
        /*Steps*/
        if ( $wip_page && isset( $_POST['_wpnonce_wip'] ) && !empty( $_POST['_wpnonce_wip'] ) ) {
            if ( isset( $_POST['wip-step-name'] ) && $_POST['wip-step-name'] ) {
                $method = $_POST['wip-step-name'];
                if ( !empty( $method ) ) {
                    switch ( $method ) {
                        case 'upload':
                            self::upload( $_POST );
                            break;
                        case 'mapping':
                            self::mapping_form( $_POST );
                            break;
                    }
                }
            }
        }
    }

    /**
     * Function to upload file in WP directory
     *
     * @param $data
     *
     * @throws IOException
     * @throws UnsupportedTypeException
     * @throws ReaderNotOpenedException
     */
    public static function upload( $data ) {
        global $wip_error;
        $msg_upload          = __( 'Veuillez choisir un ficher type EXCEL.' , WIP_PRIMARY_LANG );
        $wip_error['upload'] = array();
        if ( isset( $data['action'] ) && !empty( $data['action'] ) && 'wip-save-step' === $data['action'] ) {
            $upload_dir  = wp_upload_dir();
            $upload_file = ( !empty( $_FILES['upload']['tmp_name'] ) ) ? $_FILES['upload']['tmp_name'] : null;
            if ( !empty( $upload_dir['basedir'] ) && !is_null( $upload_file ) && is_file( $upload_file ) ) {
                $file_dirname = $upload_dir['basedir'] . WIP_UPLOAD_DIR;
                $filename     = $_FILES['upload']['name'];
                $filesize     = $_FILES['upload']['size'];
                if ( !file_exists( $file_dirname ) ) {
                    wp_mkdir_p( $file_dirname );
                }

                $reader        = ReaderFactory::create( Type::XLSX );
                $is_file_sheet = wip_is_file_sheet( $filename );
                if ( $is_file_sheet ) {
                    $reader->open( $upload_file );
                    $sheets = $reader->getSheetIterator();
                    if ( !empty( $sheets ) ) {
                        /*Has header*/

                        wip_is_valid_excel();

                        wip_empty_dir( $file_dirname . '*' );
                        $free_disk = disk_free_space( $file_dirname );
                        if ( $filesize > $free_disk ) {
                            $wip_error[ $data['wip-step-name'] ][] = __( 'Memoire insuffisante pour téléverser le fichier.' , WIP_PRIMARY_LANG );
                        } else {
                            move_uploaded_file( $upload_file , $file_dirname . $filename );
                            $referer = remove_query_arg( array( 'step' ) , wp_get_referer() );
                            $args    = array( 'step' => 'mapping' );
                            if ( isset( $data['update_existing'] ) && 1 == $data['update_existing'] ) {
                                $args['update_existing'] = $data['update_existing'];
                            }
                            if ( isset( $data['character_encoding'] ) && !empty( $data['character_encoding'] ) ) {
                                $args['character_encoding'] = $data['character_encoding'];
                            }

                            wp_safe_redirect( add_query_arg( $args , $referer ) );
                        }
                    }
                } else {
                    $wip_error['upload'][] = __( "Le fichier téléversé n'est pas un fichier EXCEL." ,
                            WIP_PRIMARY_LANG ) . ' ' . $msg_upload;
                }
            } else {
                $wip_error['upload'][] = __( 'Le fichier à téléverser est vide. ' , WIP_PRIMARY_LANG ) . ' ' . $msg_upload;
            }
        }
    }

    /**
     * Function to start import data
     *
     * @param $data
     *
     * @return bool
     */
    public static function mapping_form( $data ) {
        global $wip_error;
        $mapping_from         = $mapping_to = array();
        $wip_error['mapping'] = array();

        /*Validate file*/
        if ( empty( $data['uploaded_file'] ) ) {
            $wip_error['mapping'][] = __( 'Il n\'y a pas de fichier téléversé' , WIP_PRIMARY_LANG );

            return false;
        }
        if ( !empty( $data['uploaded_file'] ) && !is_file( $data['uploaded_file'] ) ) {
            $wip_error['mapping'][] = __( 'Le fichier' , WIP_PRIMARY_LANG );

            return false;
        }

        if ( !empty( $data['map_from'] ) && !empty( $data['map_to'] ) && empty( $wip_error['mapping'] ) ) {
            $mapping_from = wc_clean( wp_unslash( $data['map_from'] ) );
            $mapping_to   = wc_clean( wp_unslash( $data['map_to'] ) );
            $sheet_row    = WipImport::get_sheet_number();
            // Save mapping preferences for future imports.
            update_user_option( get_current_user_id() , 'woocommerce_product_import_mapping' , $mapping_to );
            if ( !empty( $sheet_row ) ) {
                update_user_option( get_current_user_id() , 'wip_product_import_number' , $sheet_row );
            }
        } else {
            wp_safe_redirect( remove_query_arg( array(
                'step' ,
                'update_existing' ,
                'character_encoding'
            ) ) , wp_get_referer() );
        }
        $update_existing    = ( isset( $_GET['update_existing'] ) && !empty( $_GET['update_existing'] ) ) ? $_GET['update_existing'] : false;
        $character_encoding = ( isset( $_GET['character_encoding'] ) && !empty( $_GET['character_encoding'] ) ) ? $_GET['character_encoding'] : 'UTF-8';
        $user_reference     = array(
            'import_nonce' => wp_create_nonce( 'wip-run-import' ) ,
            'mapping' => array(
                'from' => $mapping_from ,
                'to' => $mapping_to ,
            ) ,
            'file' => $data['uploaded_file'] ,
            'update_existing' => $update_existing ,
            'character_encoding' => $character_encoding ,
        );
        update_user_option( get_current_user_id() , 'wip_product_import_mapping_user' , $user_reference );

        $args = array( 'step' => 'progress' );
        wp_safe_redirect( add_query_arg( $args , wp_get_referer() ) );
    }

    /**
     * Return true if WooCommerce imports are allowed for current user, false otherwise.
     *
     * @return bool Whether current user can perform imports.
     */
    public static function import_allowed() {
        return current_user_can( 'edit_products' ) && current_user_can( 'import' );
    }


    /**
     * Function callback fro ajax import
     */
    public static function wip_do_ajax_import_delete() {
        $step = ( isset( $_POST['step'] ) && !empty( $_POST['step'] ) ) ? $_POST['step'] : null;
        if ( !is_null( $step ) ) {
            WipImport::remove_uploaded_file();
            update_user_option( get_current_user_id() , 'wip_product_import_mapping_user' , array() );
        }
    }


    /**
     * @param $file
     *
     * @return array
     * @throws IOException
     * @throws UnsupportedTypeException
     * @throws ReaderNotOpenedException
     */
    public static function sheet_keys( $file ) {
        global $wip_error;
        $wip_error = array();
        $reader    = ReaderFactory::create( Type::XLSX );
        $reader->open( $file );
        $sheets = $reader->getSheetIterator();
        if ( !empty( $sheets ) ) {
            foreach ( $sheets as $sheet ) {
                $sheet_name = $sheet->getName();
                if ( $sheet_name ) {
                    foreach ( $sheet->getRowIterator() as $row ) {
                        return array_filter( $row );;
                        break;
                    }
                }
            }
        } else {
            $wip_error['mapping'] = __( 'Le fichier excel n\'a pas de entête: ' , WIP_PRIMARY_LANG ) . $file;
        }
    }

    /**
     * @param $file
     *
     * @param int $index
     *
     * @return array
     * @throws IOException
     * @throws ReaderNotOpenedException
     * @throws UnsupportedTypeException
     */
    public static function sheet_data( $file , $index = 1 ) {
        global $wip_error;
        $result    = array();
        $wip_error = $data = array();
        $reader    = ReaderFactory::create( Type::XLSX );
        $reader->open( $file );
        $sheets = $reader->getSheetIterator();
        if ( !empty( $sheets ) ) {
            foreach ( $sheets as $sheet ) {
                $sheet_name = $sheet->getName();
                if ( $sheet_name ) {
                    $key = 0;
                    foreach ( $sheet->getRowIterator() as $row ) {
                        $data[ $key ] = $row;
                    }
                }
            }

            if ( !empty( $index ) && isset( $data[ $index ] ) && !empty( $data[ $index ] ) ) {
                $result = $data[ $index ];
            }

            return $result;
        }
    }

    /**
     * @return array
     * @throws IOException
     * @throws ReaderNotOpenedException
     * @throws UnsupportedTypeException
     */
    public static function get_sheet_number() {
        $data = array();
        $file = wip_uploaded_excel();
        if ( $file ) {
            $reader = ReaderFactory::create( Type::XLSX );
            $reader->open( $file );
            $sheets = $reader->getSheetIterator();
            if ( !empty( $sheets ) ) {
                foreach ( $sheets as $sheet ) {
                    $sheet_name = $sheet->getName();
                    if ( $sheet_name ) {
                        foreach ( $sheet->getRowIterator() as $key => $row ) {
                            if ( $key > 0 ) {
                                array_push( $data , $key );
                            }
                        }
                    }
                }
            }
        }

        return $data;
    }

    /**
     * @return array
     * @throws IOException
     * @throws ReaderNotOpenedException
     * @throws UnsupportedTypeException
     */
    public static function mapping_headers() {
        $file = wip_uploaded_excel();
        if ( $file ) {
            return self::sheet_keys( $file );
        }
    }

    /**
     * @param int $index
     *
     * @return array
     * @throws IOException
     * @throws ReaderNotOpenedException
     * @throws UnsupportedTypeException
     */
    public static function mapping_data( $index = 1 ) {
        $file   = wip_uploaded_excel();
        $data = array();
        if ( $file ) {
            $reader = ReaderFactory::create( Type::XLSX );
            $reader->open( $file );
            $sheets = $reader->getSheetIterator();
            if ( !empty( $sheets ) ) {
                foreach ( $sheets as $sheet ) {
                    $sheet_name = $sheet->getName();
                    if ( $sheet_name ) {
                        $key = 0;
                        foreach ( $sheet->getRowIterator() as $id => $row ) {
                            mp($row);
                            if ( $key == $index ) {
                                $data = $row;
                                break;
                            }
                            $key++;
                        }
                    }
                }
            }
        }

        return $data;
    }

    /**
     * Auto map column names.
     *
     * @param array $raw_headers Raw header columns.
     * @param bool $num_indexes If should use numbers or raw header columns as indexes.
     *
     * @return array
     */
    public static function auto_map_columns( $raw_headers = array() , $num_indexes = true ) {
        $weight_unit_label    = I18nUtil::get_weight_unit_label( get_option( 'woocommerce_weight_unit' , 'kg' ) );
        $dimension_unit_label = I18nUtil::get_dimensions_unit_label( get_option( 'woocommerce_dimension_unit' , 'cm' ) );

        /*
         * @hooked wc_importer_generic_mappings - 10
         * @hooked wc_importer_wordpress_mappings - 10
         * @hooked wc_importer_default_english_mappings - 100
         */
        $default_columns = wip_normalize_names(
            apply_filters( 'wip_excel_product_import_mapping_default_columns' ,
                array(
                    __( 'ID' , WIP_PRIMARY_LANG ) => 'id' ,
                    __( 'Type' , WIP_PRIMARY_LANG ) => 'type' ,
                    __( 'UGS' , WIP_PRIMARY_LANG ) => 'sku' ,
                    __( 'Nom' , WIP_PRIMARY_LANG ) => 'name' ,
                    __( 'Publié' , WIP_PRIMARY_LANG ) => 'published' ,
                    __( 'Mis en avant?' , WIP_PRIMARY_LANG ) => 'featured' ,
                    __( 'Visibilité dans le catalogue' , WIP_PRIMARY_LANG ) => 'catalog_visibility' ,
                    __( 'Description courte' , WIP_PRIMARY_LANG ) => 'short_description' ,
                    __( 'Description' , WIP_PRIMARY_LANG ) => 'description' ,
                    __( 'Date de début de promo' , WIP_PRIMARY_LANG ) => 'date_on_sale_from' ,
                    __( 'Date de fin de promo' , WIP_PRIMARY_LANG ) => 'date_on_sale_to' ,
                    __( 'Statut fiscal' , WIP_PRIMARY_LANG ) => 'tax_status' ,
                    __( 'Classe de taxe' , WIP_PRIMARY_LANG ) => 'tax_class' ,
                    __( 'En inventaire?' , WIP_PRIMARY_LANG ) => 'stock_status' ,
                    __( 'Inventaire' , WIP_PRIMARY_LANG ) => 'stock_quantity' ,
                    __( 'Autoriser les commandes de produits en rupture?' , WIP_PRIMARY_LANG ) => 'backorders' ,
                    __( 'Quantité d’inventaire faible' , WIP_PRIMARY_LANG ) => 'low_stock_amount' ,
                    __( 'Vendre individuellement?' , WIP_PRIMARY_LANG ) => 'sold_individually' ,
                    /* translators: %s: Weight unit */
                    sprintf( __( 'Poids (%s)' , WIP_PRIMARY_LANG ) , $weight_unit_label ) => 'weight' ,
                    /* translators: %s: Length unit */
                    sprintf( __( 'Longueur (%s)' , WIP_PRIMARY_LANG ) , $dimension_unit_label ) => 'length' ,
                    /* translators: %s: Width unit */
                    sprintf( __( 'Lur (%s)' , WIP_PRIMARY_LANG ) , $dimension_unit_label ) => 'width' ,
                    /* translators: %s: Height unit */
                    sprintf( __( 'Hauteur (%s)' , WIP_PRIMARY_LANG ) , $dimension_unit_label ) => 'height' ,
                    __( 'Autoriser les avis clients?' , WIP_PRIMARY_LANG ) => 'reviews_allowed' ,
                    __( 'Note de commande' , WIP_PRIMARY_LANG ) => 'purchase_note' ,
                    __( 'Tarif promo' , WIP_PRIMARY_LANG ) => 'sale_price' ,
                    __( 'Tarif régulier' , WIP_PRIMARY_LANG ) => 'regular_price' ,
                    __( 'Catégories' , WIP_PRIMARY_LANG ) => 'category_ids' ,
                    __( 'Étiquettes' , WIP_PRIMARY_LANG ) => 'tag_ids' ,
                    __( 'Classe de livraison' , WIP_PRIMARY_LANG ) => 'shipping_class_id' ,
                    __( 'Images' , WIP_PRIMARY_LANG ) => 'images' ,
                    __( 'Limite de téléchargement' , WIP_PRIMARY_LANG ) => 'download_limit' ,
                    __( 'Jours d’expiration du téléchargement' , WIP_PRIMARY_LANG ) => 'download_expiry' ,
                    __( 'Parent' , WIP_PRIMARY_LANG ) => 'parent_id' ,
                    __( 'Montée en gamme' , WIP_PRIMARY_LANG ) => 'upsell_ids' ,
                    __( 'Ventes croisées' , WIP_PRIMARY_LANG ) => 'cross_sell_ids' ,
                    __( 'Produits groupés' , WIP_PRIMARY_LANG ) => 'grouped_products' ,
                    __( 'URL externe' , WIP_PRIMARY_LANG ) => 'product_url' ,
                    __( 'Texte du boutton' , WIP_PRIMARY_LANG ) => 'button_text' ,
                    __( 'Position' , WIP_PRIMARY_LANG ) => 'menu_order' ,
                ) ,
                $raw_headers
            )
        );

        $special_columns = wip_get_special_names(
            apply_filters( 'wip_excel_product_import_mapping_special_columns' ,
                array(
                    /* translators: %d: Attribute number */
                    __( 'Nom de l’attribut %d' , WIP_PRIMARY_LANG ) => 'attributes:name' ,
                    /* translators: %d: Attribute number */
                    __( 'Valeur(s) de l’attribut %d' , WIP_PRIMARY_LANG ) => 'attributes:value' ,
                    /* translators: %d: Attribute number */
                    __( 'Attribut %d visible' , WIP_PRIMARY_LANG ) => 'attributes:visible' ,
                    /* translators: %d: Attribute number */
                    __( 'Attribut %d global' , WIP_PRIMARY_LANG ) => 'attributes:taxonomy' ,
                    /* translators: %d: Attribute number */
                    __( 'Attribute %d default' , WIP_PRIMARY_LANG ) => 'attributes:default' ,
                    /* translators: %d: Download number */
                    __( 'Download %d ID' , WIP_PRIMARY_LANG ) => 'downloads:id' ,
                    /* translators: %d: Download number */
                    __( 'Download %d name' , WIP_PRIMARY_LANG ) => 'downloads:name' ,
                    /* translators: %d: Download number */
                    __( 'Download %d URL' , WIP_PRIMARY_LANG ) => 'downloads:url' ,
                    /* translators: %d: Meta number */
                    __( 'Meta: %s' , WIP_PRIMARY_LANG ) => 'meta:' ,
                    __( 'SEO Description' , WIP_PRIMARY_LANG ) => 'wpseo_metadesc' ,
                ) ,
                $raw_headers
            )
        );

        $headers = self::headers_data( $raw_headers , $default_columns , $num_indexes , $special_columns );

        return apply_filters( 'wip_excel_product_import_mapped_columns' , $headers , $raw_headers );
    }

    public static function headers_data( $raw_headers , $default_columns , $num_indexes , $special_columns = array() ) {
        $headers = array();
        if ( !empty( $raw_headers ) ) {
            foreach ( $raw_headers as $key => $field ) {
                $normalized_field  = strtolower( $field );
                $index             = $num_indexes ? $key : $field;
                $headers[ $index ] = $normalized_field;

                if ( isset( $default_columns[ $normalized_field ] ) ) {
                    $headers[ $index ] = $default_columns[ $normalized_field ];
                } else {
                    if ( !empty( $special_columns ) ) {
                        foreach ( $special_columns as $regex => $special_key ) {
                            // Don't use the normalized field in the regex since meta might be case-sensitive.
                            if ( preg_match( $regex , $field , $matches ) ) {
                                $headers[ $index ] = $special_key . $matches[1];
                                break;
                            }
                        }
                    }
                }
            }
        }

        return $headers;
    }

    /**
     * Get mapping options.
     *
     * @param string $item Item name.
     *
     * @return array
     */
    public static function get_mapping_options( $item = '' ) {
        // Get index for special column names.
        $index = $item;

        if ( preg_match( '/\d+/' , $item , $matches ) ) {
            $index = $matches[0];
        }

        // Properly format for meta field.
        $meta = str_replace( 'meta:' , '' , $item );

        // Available options.
        $weight_unit_label    = I18nUtil::get_weight_unit_label( get_option( 'woocommerce_weight_unit' , 'kg' ) );
        $dimension_unit_label = I18nUtil::get_dimensions_unit_label( get_option( 'woocommerce_dimension_unit' , 'cm' ) );
        $options              = array(
            'id' => __( 'ID' , WIP_PRIMARY_LANG ) ,
            'type' => __( 'Type' , WIP_PRIMARY_LANG ) ,
            'sku' => __( 'SKU' , WIP_PRIMARY_LANG ) ,
            'name' => __( 'Nom' , WIP_PRIMARY_LANG ) ,
            'published' => __( 'Publié' , WIP_PRIMARY_LANG ) ,
            'featured' => __( 'Mis en avant?' , WIP_PRIMARY_LANG ) ,
            'catalog_visibility' => __( 'Visibilité dans le catalogue' , WIP_PRIMARY_LANG ) ,
            'short_description' => __( 'Description courte' , WIP_PRIMARY_LANG ) ,
            'description' => __( 'Description' , WIP_PRIMARY_LANG ) ,
            'price' => array(
                'name' => __( 'Prix' , WIP_PRIMARY_LANG ) ,
                'options' => array(
                    'regular_price' => __( 'Tarif régulier' , WIP_PRIMARY_LANG ) ,
                    'sale_price' => __( 'Tarif promo' , WIP_PRIMARY_LANG ) ,
                    'date_on_sale_from' => __( 'Date de début de promo' , WIP_PRIMARY_LANG ) ,
                    'date_on_sale_to' => __( 'Date de fin de promo' , WIP_PRIMARY_LANG ) ,
                ) ,
            ) ,
            'tax_status' => __( 'Statut fiscal' , WIP_PRIMARY_LANG ) ,
            'tax_class' => __( 'Classe de taxe' , WIP_PRIMARY_LANG ) ,
            'stock_status' => __( 'En inventaire?' , WIP_PRIMARY_LANG ) ,
            'stock_quantity' => __( 'Inventaire?' , WIP_PRIMARY_LANG ) ,
            'backorders' => __( 'Autoriser les commandes de produits en rupture?' , WIP_PRIMARY_LANG ) ,
            'low_stock_amount' => __( 'Quantité d’inventaire faible' , WIP_PRIMARY_LANG ) ,
            'sold_individually' => __( 'Vendre individuellement?' , WIP_PRIMARY_LANG ) ,
            /* translators: %s: weight unit */
            'weight' => sprintf( __( 'Poids (%s)' , WIP_PRIMARY_LANG ) , $weight_unit_label ) ,
            'dimensions' => array(
                'name' => __( 'Dimensions' , WIP_PRIMARY_LANG ) ,
                'options' => array(
                    /* translators: %s: dimension unit */
                    'length' => sprintf( __( 'Longueur (%s)' , WIP_PRIMARY_LANG ) , $dimension_unit_label ) ,
                    /* translators: %s: dimension unit */
                    'width' => sprintf( __( 'Lur (%s)' , WIP_PRIMARY_LANG ) , $dimension_unit_label ) ,
                    /* translators: %s: dimension unit */
                    'height' => sprintf( __( 'Hauteur (%s)' , WIP_PRIMARY_LANG ) , $dimension_unit_label ) ,
                ) ,
            ) ,
            'category_ids' => __( 'Catégories' , WIP_PRIMARY_LANG ) ,
            'tag_ids' => __( 'Étiquettes' , WIP_PRIMARY_LANG ) ,
            'tag_ids_spaces' => __( 'Étiquettes (séparées par des espaces)' , WIP_PRIMARY_LANG ) ,
            'shipping_class_id' => __( 'Classe de livraison' , WIP_PRIMARY_LANG ) ,
            'images' => __( 'Images' , WIP_PRIMARY_LANG ) ,
            'parent_id' => __( 'Parent' , WIP_PRIMARY_LANG ) ,
            'upsell_ids' => __( 'Montée en gamme' , WIP_PRIMARY_LANG ) ,
            'cross_sell_ids' => __( 'Ventes croisées' , WIP_PRIMARY_LANG ) ,
            'grouped_products' => __( 'Produits groupés' , WIP_PRIMARY_LANG ) ,
            'external' => array(
                'name' => __( 'Produit externe' , WIP_PRIMARY_LANG ) ,
                'options' => array(
                    'product_url' => __( 'URL externe' , WIP_PRIMARY_LANG ) ,
                    'button_text' => __( 'Texte du boutton' , WIP_PRIMARY_LANG ) ,
                ) ,
            ) ,
            'downloads' => array(
                'name' => __( 'Téléchargement' , WIP_PRIMARY_LANG ) ,
                'options' => array(
                    'downloads:id' . $index => __( "ID téléchargement $index" , WIP_PRIMARY_LANG ) ,
                    'downloads:name' . $index => __( "Nom téléchargement $index" , WIP_PRIMARY_LANG ) ,
                    'downloads:url' . $index => __( "URL téléchargement $index" , WIP_PRIMARY_LANG ) ,
                    'download_limit' => __( "Limite de téléchargement" , WIP_PRIMARY_LANG ) ,
                    'download_expiry' => __( "Jours d’expiration du téléchargement" , WIP_PRIMARY_LANG ) ,
                ) ,
            ) ,
            'attributes' => array(
                'name' => __( 'Attributs' , WIP_PRIMARY_LANG ) ,
                'options' => array(
                    'attributes:name' . $index => __( "Nom de l’attribut $index" , WIP_PRIMARY_LANG ) ,
                    'attributes:value' . $index => __( "Valeur(s) de l’attribut $index" , WIP_PRIMARY_LANG ) ,
                    'attributes:taxonomy' . $index => __( "Attribut $index global" , WIP_PRIMARY_LANG ) ,
                    'attributes:visible' . $index => __( "Visibilité de l’attribut $index" , WIP_PRIMARY_LANG ) ,
                    'attributes:default' . $index => __( 'Attribut par default' , WIP_PRIMARY_LANG ) ,
                ) ,
            ) ,
            'reviews_allowed' => __( 'Autoriser les avis clients?' , WIP_PRIMARY_LANG ) ,
            'purchase_note' => __( 'Note de commande' , WIP_PRIMARY_LANG ) ,
            'meta:' . $meta => __( 'Importer comme meta data' , WIP_PRIMARY_LANG ) ,
            'menu_order' => __( 'Position' , WIP_PRIMARY_LANG ) ,
            'wpseo_metadesc' => __( 'SEO Description' , WIP_PRIMARY_LANG ) ,
        );

        return apply_filters( 'wip_excel_product_import_mapping_options' , $options , $item );
    }


    public static function expand_data( $data ) {
        $data = apply_filters( 'woocommerce_product_importer_pre_expand_data' , $data );

        // Images field maps to image and gallery id fields.
        if ( isset( $data['images'] ) ) {
            $images               = $data['images'];
            $data['raw_image_id'] = array_shift( $images );

            if ( !empty( $images ) ) {
                $data['raw_gallery_image_ids'] = $images;
            }
            unset( $data['images'] );
        }

// Type, virtual and downloadable are all stored in the same column.
        if ( isset( $data['type'] ) ) {
            $data['type']         = array_map( 'strtolower' , $data['type'] );
            $data['virtual']      = in_array( 'virtual' , $data['type'] , true );
            $data['downloadable'] = in_array( 'downloadable' , $data['type'] , true );

            // Convert type to string.
            $data['type'] = current( array_diff( $data['type'] , array( 'virtual' , 'downloadable' ) ) );

            if ( !$data['type'] ) {
                $data['type'] = 'simple';
            }
        }

// Status is mapped from a special published field.
        if ( isset( $data['published'] ) ) {
            $published = $data['published'];
            if ( is_float( $published ) ) {
                $published = (int)$published;
            }

            $statuses       = array(
                -1 => 'draft' ,
                0 => 'private' ,
                1 => 'publish' ,
            );
            $data['status'] = $statuses[ $published ] ?? 'draft';

            // Fix draft status of variations.
            if ( 'variation' === ( $data['type'] ?? null ) && -1 === $published ) {
                $data['status'] = 'publish';
            }

            unset( $data['published'] );
        }

        if ( isset( $data['stock_quantity'] ) ) {
            if ( '' === $data['stock_quantity'] ) {
                $data['manage_stock'] = false;
                $data['stock_status'] = isset( $data['stock_status'] ) ? $data['stock_status'] : true;
            } else {
                $data['manage_stock'] = true;
            }
        }

// Stock is bool or 'backorder'.
        if ( isset( $data['stock_status'] ) ) {
            if ( 'backorder' === $data['stock_status'] ) {
                $data['stock_status'] = 'onbackorder';
            } else {
                $data['stock_status'] = $data['stock_status'] ? 'instock' : 'outofstock';
            }
        }

// Prepare grouped products.
        if ( isset( $data['grouped_products'] ) ) {
            $data['children'] = $data['grouped_products'];
            unset( $data['grouped_products'] );
        }

// Tag ids.
        if ( isset( $data['tag_ids_spaces'] ) ) {
            $data['tag_ids'] = $data['tag_ids_spaces'];
            unset( $data['tag_ids_spaces'] );
        }

// Handle special column names which span multiple columns.
        $attributes = array();
        $downloads  = array();
        $meta_data  = array();

        foreach ( $data as $key => $value ) {
            if ( wip_field_starts_with( $key , 'attributes:name' ) ) {
                if ( !empty( $value ) ) {
                    $attributes[ str_replace( 'attributes:name' , '' , $key ) ]['name'] = $value;
                }
                unset( $data[ $key ] );

            } elseif ( wip_field_starts_with( $key , 'attributes:value' ) ) {
                $attributes[ str_replace( 'attributes:value' , '' , $key ) ]['value'] = $value;
                unset( $data[ $key ] );

            } elseif ( wip_field_starts_with( $key , 'attributes:taxonomy' ) ) {
                $attributes[ str_replace( 'attributes:taxonomy' , '' , $key ) ]['taxonomy'] = wc_string_to_bool( $value );
                unset( $data[ $key ] );

            } elseif ( wip_field_starts_with( $key , 'attributes:visible' ) ) {
                $attributes[ str_replace( 'attributes:visible' , '' , $key ) ]['visible'] = wc_string_to_bool( $value );
                unset( $data[ $key ] );

            } elseif ( wip_field_starts_with( $key , 'attributes:default' ) ) {
                if ( !empty( $value ) ) {
                    $attributes[ str_replace( 'attributes:default' , '' , $key ) ]['default'] = $value;
                }
                unset( $data[ $key ] );

            } elseif ( wip_field_starts_with( $key , 'downloads:id' ) ) {
                if ( !empty( $value ) ) {
                    $downloads[ str_replace( 'downloads:id' , '' , $key ) ]['id'] = $value;
                }
                unset( $data[ $key ] );

            } elseif ( wip_field_starts_with( $key , 'downloads:name' ) ) {
                if ( !empty( $value ) ) {
                    $downloads[ str_replace( 'downloads:name' , '' , $key ) ]['name'] = $value;
                }
                unset( $data[ $key ] );

            } elseif ( wip_field_starts_with( $key , 'downloads:url' ) ) {
                if ( !empty( $value ) ) {
                    $downloads[ str_replace( 'downloads:url' , '' , $key ) ]['url'] = $value;
                }
                unset( $data[ $key ] );

            } elseif ( wip_field_starts_with( $key , 'meta:' ) ) {
                $meta_data[] = array(
                    'key' => str_replace( 'meta:' , '' , $key ) ,
                    'value' => $value ,
                );
                unset( $data[ $key ] );
            }
        }

        if ( !empty( $attributes ) ) {
            // Remove empty attributes and clear indexes.
            foreach ( $attributes as $attribute ) {
                if ( empty( $attribute['name'] ) ) {
                    continue;
                }

                $data['raw_attributes'][] = $attribute;
            }
        }

        if ( !empty( $downloads ) ) {
            $data['downloads'] = array();

            foreach ( $downloads as $key => $file ) {
                if ( empty( $file['url'] ) ) {
                    continue;
                }

                $data['downloads'][] = array(
                    'download_id' => isset( $file['id'] ) ? $file['id'] : null ,
                    'name' => $file['name'] ? $file['name'] : wc_get_filename_from_url( $file['url'] ) ,
                    'file' => $file['url'] ,
                );
            }
        }

        if ( !empty( $meta_data ) ) {
            $data['meta_data'] = $meta_data;
        }

        return $data;

    }

    /**
     * Map columns using the user's latest import mappings.
     *
     * @param array $headers Header columns.
     *
     * @return array
     */
    public static function auto_map_user_preferences( $headers ) {
        $mapping_preferences = get_user_option( 'woocommerce_product_import_mapping' );

        if ( !empty( $mapping_preferences ) && is_array( $mapping_preferences ) ) {
            return $mapping_preferences;
        }

        return $headers;
    }

    public static function remove_uploaded_file() {
        $upload_dir   = wp_upload_dir();
        $file_dirname = $upload_dir['basedir'] . WIP_UPLOAD_DIR;
        wip_empty_dir( $file_dirname . '*' );
    }

    /**
     * Process importer.
     *
     * Do not import products with IDs or SKUs that already exist if option
     * update existing is false, and likewise, if updating products, do not
     * process rows which do not exist if an ID/SKU is provided.
     *
     * @return array
     * @throws Exception
     */
    public function import() {
        $this->start_time = time();
        $index            = 0;
        $update_existing  = $this->params['update_existing'];
        $data             = array(
            'imported' => array() ,
            'imported_variations' => array() ,
            'failed' => array() ,
            'updated' => array() ,
            'skipped' => array() ,
        );

        foreach ( $this->parsed_data as $parsed_data_key => $parsed_data ) {
            do_action( 'woocommerce_product_import_before_import' , $parsed_data );

            $id         = isset( $parsed_data['id'] ) ? absint( $parsed_data['id'] ) : 0;
            $sku        = isset( $parsed_data['sku'] ) ? $parsed_data['sku'] : '';
            $id_exists  = false;
            $sku_exists = false;

            if ( $id ) {
                $product   = wc_get_product( $id );
                $id_exists = $product && 'importing' !== $product->get_status();
            }

            if ( $sku ) {
                $id_from_sku = wc_get_product_id_by_sku( $sku );
                $product     = $id_from_sku ? wc_get_product( $id_from_sku ) : false;
                $sku_exists  = $product && 'importing' !== $product->get_status();
            }

            if ( $id_exists && !$update_existing ) {
                $data['skipped'][] = new WP_Error(
                    'woocommerce_product_importer_error' ,
                    esc_html__( 'A product with this ID already exists.' , 'woocommerce' ) ,
                    array(
                        'id' => $id ,
                        'row' => $this->get_row_id( $parsed_data ) ,
                    )
                );
                continue;
            }

            if ( $sku_exists && !$update_existing ) {
                $data['skipped'][] = new WP_Error(
                    'woocommerce_product_importer_error' ,
                    esc_html__( 'A product with this SKU already exists.' , 'woocommerce' ) ,
                    array(
                        'sku' => esc_attr( $sku ) ,
                        'row' => $this->get_row_id( $parsed_data ) ,
                    )
                );
                continue;
            }

            if ( $update_existing && ( isset( $parsed_data['id'] ) || isset( $parsed_data['sku'] ) ) && !$id_exists && !$sku_exists ) {
                $data['skipped'][] = new WP_Error(
                    'woocommerce_product_importer_error' ,
                    esc_html__( 'No matching product exists to update.' , 'woocommerce' ) ,
                    array(
                        'id' => $id ,
                        'sku' => esc_attr( $sku ) ,
                        'row' => $this->get_row_id( $parsed_data ) ,
                    )
                );
                continue;
            }

            $result = $this->process_item( $parsed_data );

            if ( is_wp_error( $result ) ) {
                $result->add_data( array( 'row' => $this->get_row_id( $parsed_data ) ) );
                $data['failed'][] = $result;
            } elseif ( $result['updated'] ) {
                $data['updated'][] = $result['id'];
            } else {
                if ( $result['is_variation'] ) {
                    $data['imported_variations'][] = $result['id'];
                } else {
                    $data['imported'][] = $result['id'];
                }
            }

            $index++;

            if ( $this->params['prevent_timeouts'] && ( $this->time_exceeded() || $this->memory_exceeded() ) ) {
                $this->file_position = $this->file_positions[ $index ];
                break;
            }
        }

        return $data;
    }

    /**
     * Convert a string from the input encoding to UTF-8.
     *
     * @param string $value The string to convert.
     * @param $encoding
     *
     * @return string The converted string.
     */
    public static function adjust_character_encoding( $value ) {
        $mapping  = get_user_option( 'wip_product_import_mapping_user' );
        $encoding = $mapping['character_encoding'];
        if ( isset( $user_encoding ) && !empty( $user_encoding ) && 'UTF-8' !== $user_encoding ) {
            mb_convert_encoding( $value , 'UTF-8' , $encoding );
        } else {
            return $value;
        }
    }


}