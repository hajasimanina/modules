<?php
if ( !function_exists( 'wip_empty_dir' ) ) {
	function wip_empty_dir( $directory ) {
		$files = glob( $directory );
		if ( !empty( $files ) ) {
			foreach ( $files as $file ) {
				unlink( $file );
			}
		}
	}
}

if ( !function_exists( 'wip_uploded_excel' ) ) {
	function wip_uploaded_excel() {
		$upload_dir = wp_upload_dir();
		if ( !empty( $upload_dir['basedir'] ) ) {
			$file_dirname = $upload_dir['basedir'] . WIP_UPLOAD_DIR . '*';
			$files        = glob( $file_dirname );
			if ( !empty( $files ) ) {
				$file = array_shift( $files );
				if ( is_file( $file ) ) {
					$is_sheet = wip_is_file_sheet( basename( $file ) );
					if ( $is_sheet ) {
						return $file;
					} else {
						return false;
					}
				}
			}
		}
	}
}

if ( !function_exists( 'wip_file_extension' ) ) {
	function wip_file_extension( $filename ) {
		$infos = explode( '.' , $filename );
		if ( !empty( $infos ) ) {
			return end( $infos );
		} else {
			return null;
		}
	}
}

if ( !function_exists( 'wip_is_file_sheet' ) ) {
	function wip_is_file_sheet( $filename ) {
		$file_type = wp_check_filetype( $filename );
		if ( !empty( $file_type ) && in_array( $file_type['ext'] , array( 'xlsx' , 'xls' ) ) ) {
			return true;
		} else {
			return false;
		}
	}
}

if ( !function_exists( 'wip_get_page' ) ) {
	function wip_get_page() {
		if ( isset( $_GET['page'] ) && !empty( $_GET['page'] ) && 'page-wip-produit' === $_GET['page'] ) {
			return true;
		} else {
			return false;
		}
	}
}

if ( !function_exists( 'wip_is_valid_excel' ) ) {
	function wip_is_valid_excel() {
		$headers = WipImport::mapping_headers();

		if ( empty( $headers ) ) {
			$wip_error['upload'][] = __( "Le fichier téléversé n'est pas un entête." , WIP_PRIMARY_LANG );

			return $wip_error;
		}

		if ( !empty( $headers ) && !in_array( __( 'Name' , 'woocomerce' ) , $headers ) ) {
			$wip_error['upload'][] = __( "L'entêten(Ligne 1) du fichier téléversé n'est pas valide." ,
				WIP_PRIMARY_LANG );

			return $wip_error;
		}

		return true;
	}
}

if ( !function_exists( 'wip_sanitize_special_name_regex' ) ) {
	function wip_sanitize_special_name_regex( $value ) {
		return '/' . str_replace( array( '%d' , '%s' ) , '(.*)' , trim( quotemeta( $value ) ) ) . '/i';
	}
}

if ( !function_exists( 'wip_get_special_names' ) ) {
	function wip_get_special_names( $names ) {
		$formatted = array();

		if ( !empty( $names ) ) {
			foreach ( $names as $key => $value ) {
				$regex               = wip_sanitize_special_name_regex( $key );
				$formatted[ $regex ] = $value;
			}
		}

		return $formatted;
	}
}

if ( !function_exists( 'wip_normalize_names' ) ) {
	function wip_normalize_names( $names ) {
		$normalized = array();

		if ( !empty( $names ) ) {
			foreach ( $names as $key => $value ) {
				$normalized[ strtolower( $key ) ] = $value;
			}
		}

		return $normalized;
	}
}

if ( !function_exists( 'wip_field_starts_with' ) ) {
	function wip_field_starts_with( $haystack , $needle ) {
		return substr( $haystack , 0 , strlen( $needle ) ) === $needle;
	}
}

