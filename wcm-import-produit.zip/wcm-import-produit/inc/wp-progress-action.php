<?php

class WP_Progress_Action {
	public $element_slug;
	public $element_label;
	public $labels;

	public function __construct(
		$element_slug , $element_label = "Elément" , $labels = array(
		'process_title' => 'Traitement'

	)
	) {
		$this->element_slug  = $element_slug;
		$this->element_label = $element_label;
		$this->labels        = $labels;
	}


	public static function progress_action_callback() {
		@error_reporting( 0 ); // Don't break the JSON result

		header( 'Content-type: application/json' );

		$id      = (int) $_REQUEST['id'];
		$element = $_REQUEST['element'];
		$return  = apply_filters( 'progress_action_callback_' . $element , $id );

		if ( $return !== true ) {
			self::die_json_error_msg( $id , $return );
		}

		@set_time_limit( 900 ); // 5 minutes per process should be PLENTY

		die( json_encode( array( 'success' => sprintf( 'Succès lors du traitement du ID : %1$s. Temps de traitement en %2$s secondes.' , $id , timer_stop() ) ) ) );
	}

	// Helper to make a JSON error message
	public static function die_json_error_msg( $id , $message ) {
		die( json_encode( array( 'error' => sprintf( 'Echec lors du traitement du ID : %1$s . Le message d\'erreur est: %2$s' , $id , $message ) ) ) );
	}

	public function display() {
		?>
        <div id="message" class="updated fade" style=""></div>

        <div class="wip-progress-form-content ProgressActionProcessus">
            <header>
                <h2><?php esc_html_e( 'Importation' , WIP_PRIMARY_LANG ); ?></h2>
				<?php
				$elements = apply_filters( 'progress_action_data_' . $this->element_slug , array() );

				if ( empty( $elements ) || !$elements ) {
					echo '	<p>Aucun ' . $this->element_label . ' trouvé.</p></div>';

					return;
				}

				if ( is_array( $elements ) ) {
					$ids = implode( ',' , $elements );
				}
				?>
                <p class="message">
					<?php
					echo __( '<strong>Vos produits sont maintenant prêt à importer</strong>.' , WIP_PRIMARY_LANG );
					?>
                </p>
                <p>
                    Veuillez patienter pendant le traitement des produits<br>.
                    Cela peut prendre un certain temps si votre serveur est lent ou si vous avez beaucoup des produits à
                    importer.<br>
                    Ne quittez pas cette page jusqu'à ce que ce script soit fini. Vous serez averti par cette page
                    lorsque l'operation est terminée.
                </p>
            </header>
			<?php

			$count           = count( $elements );
			$text_failures   = sprintf( 'Tout est fait! %1$s ' . $this->element_label . '(s) ont été traité avec succès en %2$s secondes et il y a %3$s echec(s).' , "' + cpi_successes + '" , "' + cpi_totaltime + '" , "' + cpi_errors + '" );
			$text_nofailures = sprintf( 'Tout est fait! %1$s ' . $this->element_label . '(s) ont été généré avec succès en %2$s secondes et il y a 0 echec.' , "' + cpi_successes + '" , "' + cpi_totaltime + '" );
			?>


            <noscript><p><em><?php echo 'Vous devez activer Javascript avant de procéder!'; ?></em></p></noscript>

            <section>
                <div id="progress-bar-processus-bar" style="position:relative;height:25px;">
                    <div id="progress-bar-processus-bar-percent"
                         style="position:absolute;left:50%;top:50%;width:300px;margin-left:-150px;height:25px;margin-top:-9px;font-weight:bold;text-align:center;">
                    </div>
                </div>
            </section>
            <div class="wip-actions">
                <input type="button" class="button button-primary hide-if-no-js" name="progress-bar-processus-start"
                       id="progress-bar-processus-start" value="<?php echo 'Demarrer le traitement'; ?>"/>
                <input type="button" class="button hide-if-no-js" name="progress-bar-processus-stop"
                       id="progress-bar-processus-stop" value="<?php echo 'Annuler le traitement'; ?>"/>
            </div>

            <h3 class="title"><?php echo __( 'Informations' , WIP_PRIMARY_LANG ); ?></h3>

            <p>
				<?php printf( 'Total ' . $this->element_label . 's: %s' , $count ); ?><br/>
				<?php printf( 'Import avec succès : %s' , '<span id="progress-bar-processus-debug-successcount">0</span>'
				); ?>
                <br/>
				<?php printf( 'Imports echoués : %s' , '<span id="progress-bar-processus-debug-failurecount">0</span>' ); ?>
            </p>

            <ol id="progress-bar-processus-debuglist">
                <li style="display:none"></li>
            </ol>


            <script type="text/javascript">
                jQuery(document).ready(function ($) {
                    var i;
                    var cpi_elements = [<?php echo $ids; ?>];
                    var cpi_total = cpi_elements.length;
                    var cpi_count = 1;
                    var cpi_percent = 0;
                    var cpi_successes = 0;
                    var cpi_errors = 0;
                    var cpi_failedlist = '';
                    var cpi_resulttext = '';
                    var cpi_timestart = new Date().getTime();
                    var cpi_timeend = 0;
                    var cpi_totaltime = 0;
                    var cpi_continue = true;

                    // Create the progress bar
                    $("#progress-bar-processus-bar").progressbar();
                    $("#progress-bar-processus-bar-percent").html("0%");

                    // Stop button
                    $("#progress-bar-processus-stop").click(function (e) {
                        e.preventDefault();
                        cpi_continue = false;
                        $('#progress-bar-processus-stop').val("<?php echo 'Annulation import...'; ?>");
                    });

                    // Clear out the empty list element that's there for HTML validation purposes
                    $("#progress-bar-processus-debuglist li").remove();

                    // Called after each resize. Updates debug information and the progress bar.
                    function ProgressActionUpdateStatus(id, success, response) {
                        $("#progress-bar-processus-bar").progressbar("value", (cpi_count / cpi_total) * 100);
                        $("#progress-bar-processus-bar-percent").html(Math.round((cpi_count / cpi_total) * 1000) / 10 + "%");
                        cpi_count = cpi_count + 1;

                        if (success) {
                            cpi_successes = cpi_successes + 1;
                            $("#progress-bar-processus-debug-successcount").html(cpi_successes);
                            $("#progress-bar-processus-debuglist").append("<li>" + response.success + "</li>");
                        } else {
                            cpi_errors = cpi_errors + 1;
                            cpi_failedlist = cpi_failedlist + ',' + id;
                            $("#progress-bar-processus-debug-failurecount").html(cpi_errors);
                            $("#progress-bar-processus-debuglist").append("<li>" + response.error + "</li>");
                        }
                    }

                    // Called when all images have been processed. Shows the results and cleans up.
                    function ProgressActionFinishUp() {
                        cpi_timeend = new Date().getTime();
                        cpi_totaltime = Math.round((cpi_timeend - cpi_timestart) / 1000);

                        $('#progress-bar-processus-stop').hide();
                        $('#progress-bar-processus-start').hide();

                        if (cpi_errors > 0) {
                            cpi_resulttext = '<?php echo $text_failures; ?>';
                        } else {
                            cpi_resulttext = '<?php echo $text_nofailures; ?>';
                        }

                        $("#message").html("<p><strong>" + cpi_resulttext + "</strong></p>");
                        $("#message").show();
                    }

                    // processus via AJAX
                    function ProgressActionProcessus(id) {
                        $.ajax({
                            type: 'POST',
                            url: '<?php echo admin_url( '/admin-ajax.php' );?>',
                            data: {action: "progress_action", id: id, element: '<?php echo $this->element_slug; ;?>'},
                            success: function (response) {
                                if (response !== Object(response) || (typeof response.success === "undefined" && typeof response.error === "undefined")) {
                                    response = new Object;
                                    response.success = false;
                                    response.error = "<?php printf( esc_js( 'Le traitement s\'est terminé anormalement (ID %s). Fatal error.' ) , '" + id + "' ); ?>";
                                }

                                if (response.success) {
                                    ProgressActionUpdateStatus(id, true, response);
                                } else {
                                    ProgressActionUpdateStatus(id, false, response);
                                }

                                if (cpi_elements.length && cpi_continue) {
                                    ProgressActionProcessus(cpi_elements.shift());
                                } else {
                                    ProgressActionFinishUp();
                                }
                            },
                            error: function (response) {
                                ProgressActionUpdateStatus(id, false, response);

                                if (cpi_elements.length && cpi_continue) {
                                    ProgressActionProcessus(cpi_elements.shift());
                                } else {
                                    ProgressActionFinishUp();
                                }
                            }
                        });
                    }

                    jQuery("#progress-bar-processus-start").click(function () {
                        ProgressActionProcessus(cpi_elements.shift());
                    });
                });
            </script>
        </div>

		<?php
	}
}

add_action( 'wp_ajax_progress_action' , array( 'WP_Progress_Action' , 'progress_action_callback' ) );