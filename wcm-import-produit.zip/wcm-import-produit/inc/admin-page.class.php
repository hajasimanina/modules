<?php

require_once( WIP_ROOT_DIR . '/lib/Spout/Autoloader/autoload.php' );
require_once( WIP_ROOT_DIR . '/inc/import.class.php' );

class WIP_Admin_Page {

	/**
	 * WIP_Admin_Page constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu' , array( $this , 'add_menu' ) );
		add_action( 'admin_enqueue_scripts' , array( $this , 'admin_enqueues' ) );
		add_action( 'admin_init' , 'WipImport::save_step' );
	}

	/**
	 * Admin menu
	 */
	public function add_menu() {
		add_menu_page(
			__( 'Import des products dans WooCommerce dépuis un fichier Excel' , WIP_PRIMARY_LANG ) ,
			__( 'Import Produit' , WIP_PRIMARY_LANG ) ,
			'manage_options' ,
			'page-wip-produit' ,
			array( $this , 'admin_page' ) ,
			'dashicons-products' ,
			10
		);
	}

	/**
	 * Add CSS and JS
	 */
	public function admin_enqueues() {
		//CSS
		wp_enqueue_style( 'wip-custom-style' , WIP_URL . 'assets/css/style.css' );
		wp_enqueue_style( 'jquery-ui-progress-bar-processus' , WIP_URL . 'assets/jquery-ui/redmond/jquery-ui-1.7.2.custom.css' , array() , '1.7.2' );

		//JS
		// WordPress 3.1 vs older version compatibility
		if ( wp_script_is( 'jquery-ui-widget' , 'registered' ) ) {
			wp_enqueue_script( 'jquery-ui-progressbar' , WIP_URL . 'lib/jquery-ui/jquery.ui.progressbar.min.js' , array(
				'jquery-ui-core' ,
				'jquery-ui-widget'
			) , '1.8.6' );
		} else {
			wp_enqueue_script( 'jquery-ui-progressbar' , WIP_URL . 'lib/jquery-ui/jquery.ui.progressbar.min.1.7.2.js' , array( 'jquery-ui-core' ) , '1.7.2' );
		}

		wp_enqueue_script( 'wip-custom-script' , WIP_URL . 'assets/js/script.js' , array( 'jquery' ) );
	/*	wp_localize_script( 'wip-custom-script' , 'wip_object' , array(
			'ajaxurl' => admin_url( 'admin-ajax.php' ) ,
		) );*/


		// WordPress 3.1 vs older version compatibility
		if ( wp_script_is( 'jquery-ui-widget' , 'registered' ) ) {
			wp_enqueue_script( 'jquery-ui-progressbar' , WIP_URL . 'assets/jquery-ui/jquery.ui.progressbar.min.js' , array(
				'jquery-ui-core' ,
				'jquery-ui-widget'
			) , '1.8.6' );
		} else {
			wp_enqueue_script( 'jquery-ui-progressbar' , WIP_URL . 'assets/jquery-ui/jquery.ui.progressbar.min.1.7.2.js' , array( 'jquery-ui-core' ) , '1.7.2' );
		}

	}

	/**
	 * Admin page
	 */
	public function admin_page() {
		ob_start();
		global $current_step;
		$current_step = ( isset( $_GET['step'] ) && !empty( $_GET['step'] ) ) ? $_GET['step'] : 'upload';
		include WIP_ROOT_DIR . '/templates/admin.tpl.php';

		echo ob_get_clean();
	}

	/**
	 * Manage import steps
	 *
	 * @param $step
	 */
	public static function dispatch( $step ) {
		ob_start();
		$include_file = WIP_ROOT_DIR . "templates/views/html-excel-import-" . $step . ".php";

		if ( file_exists( $include_file ) ) {
			include $include_file;
			echo ob_get_clean();
		} else {
			echo '<span>' . __( 'Fichier n\'existe pas' , WIP_PRIMARY_LANG ) . '</span>';
		}
	}
}
